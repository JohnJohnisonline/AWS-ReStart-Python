def printHello(name):

     print("Hello " + name + "! Welcome to the AWS re/Start program")

value = input("Please enter a name:\n")

printHello(value)